# Emetric 0.42.0-beta.1 — Public Beta

This package contains the public beta script for Adobe InDesign.

## Run

Open Adobe InDesign and run:

```text
Emetric-0.42.0-beta.1.jsx
```

## Documentation

- `RELEASE_NOTES.md`
- `LICENSE.md`
- `docs/installation.md`
- `docs/beta-testing.md`
- `docs/manual-test-checklist.md`
- `docs/presets.md`
- `docs/img/`

## License

Emetric is distributed under the Emetric Beta License. It is free for evaluation and beta testing, but it is not open source. Redistribution, resale and repackaging are not permitted without written permission.
