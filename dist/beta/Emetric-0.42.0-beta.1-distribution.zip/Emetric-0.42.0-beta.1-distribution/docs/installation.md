# Installation

## Quick test install

1. Download and unzip the release package.
2. Locate `Emetric-0.42.0-beta.1.jsx` at the package root.
3. In Adobe InDesign, open the Scripts panel.
4. Reveal the Scripts Panel folder in Finder/Explorer.
5. Copy `Emetric-0.42.0-beta.1.jsx` into the Scripts Panel folder.
6. Return to InDesign and run the script from the Scripts panel.

## Alternative: run from ExtendScript / script runner

You can also run the file directly from a script runner or development environment that supports Adobe InDesign ExtendScript.

## Presets and saved state

Emetric stores presets and last-used UI state locally per user:

```text
Folder.userData/Emetric/presets.json
```

On macOS this usually resolves to something like:

```text
~/Library/Application Support/Emetric/presets.json
```

## Recommended beta test workflow

1. Start InDesign.
2. Run `Emetric-0.42.0-beta.1.jsx`.
3. Use `tests/manual-test-checklist.md` as the baseline checklist.
4. Report operating system, InDesign version, font used, steps to reproduce, expected result, actual result, and screenshots if possible.
