# Emetric 0.42.0-beta.1 — Release Notes

First public-facing beta build for wider manual testing in Adobe InDesign.

## Status

- Version: `0.42.0-beta.1`
- Release status: Beta
- Main script: `Emetric-0.42.0-beta.1.jsx`
- Source file: `src/indesign/Emetric.jsx`
- Distribution file: `dist/beta/Emetric-0.42.0-beta.1.jsx`

## What is included

- Installable Adobe InDesign ExtendScript file at the package root.
- Source file under `src/indesign/`.
- Versioned distribution file under `dist/beta/`.
- Manual beta test checklist under `tests/`.
- README, changelog, contributing notes, installation guide, and proprietary license.

## Highlights

- Three-column Emetric interface for type-based layout construction.
- Metric sources: Selected Font, Emetric Decimal, Emetric Dozenal, and Custom Metric.
- Custom Metric now uses the existing Type Size fields as manual, independent metric values.
- Page Size format selector with common document sizes such as A4, A3, Letter, Legal, and related formats.
- Type Defined Format and Custom Format modes.
- Vertical and Horizontal Grid sections with Grid Interval, Steps, Alignment, Module Height/Width, Grid Height/Width, and Offset.
- Optional Placeholder Text and Emetric Data pages.
- Generated InDesign margins, columns, grids, guides, layers, and paragraph-style updates.
- Presets saved locally in the user data folder.

## Known beta focus areas

Please test especially:

- Custom Metric behavior and manual Type Size values.
- Vertical Grid Alignment, especially Ascender, Cap Height, x-Height, and Metrics.
- Page Size format selector behavior, including A4 and custom formats.
- Horizontal Grid Guides when left and right margins differ.
- Colors panel label stability when switching Metric Source.
- Placeholder Text behavior with [Basic Paragraph].
- Layer and Paragraph Style creation only when the related options are enabled.
- Preset save/load behavior.

## Installation

See `docs/installation.md`.

## Manual testing

Use `tests/manual-test-checklist.md` when testing and reporting issues.

## Notes

This release is proprietary beta software. It is provided for testing and feedback only.
